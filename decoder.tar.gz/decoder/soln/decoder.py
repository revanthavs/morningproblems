# Read in the input

# Solve the problem, good luck!
