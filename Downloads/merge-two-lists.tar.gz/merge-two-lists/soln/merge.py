# Get the input

# now do something similar to get the list of vehicles in the right lane


# Solve the problem


# Print the result
