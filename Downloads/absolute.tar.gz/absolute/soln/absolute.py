# Read in the input

# Solve the problem

# Output the result