# Read in the input

# Solve the problem and output the result
